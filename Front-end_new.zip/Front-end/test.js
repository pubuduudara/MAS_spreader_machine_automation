// <!-- The core Firebase JS SDK is always required and must be listed first -->
// <script src="https://www.gstatic.com/firebasejs/7.8.0/firebase-app.js"></script>
 
// <!-- TODO: Add SDKs for Firebase products that you want to use
//      https://firebase.google.com/docs/web/setup#available-libraries -->
// <script src="https://www.gstatic.com/firebasejs/7.8.0/firebase-analytics.js"></script>
 
// <script>
//   // Your web app's Firebase configuration
//   var firebaseConfig = {
//     apiKey: "AIzaSyCfbDEvntAjCft006d_t9fQuNwuVHmBl3s",
//     authDomain: "masdemo-146c2.firebaseapp.com",
//     databaseURL: "https://masdemo-146c2.firebaseio.com",
//     projectId: "masdemo-146c2",
//     storageBucket: "masdemo-146c2.appspot.com",
//     messagingSenderId: "253329309704",
//     appId: "1:253329309704:web:376b0267bee7a9dad411bd",
//     measurementId: "G-XKDMFRXJBF"
//   };
//   // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);
//   firebase.analytics();
// </script>


let sumit = (a,b) => a+b

console.log(sumit(12,34));

