
var firebaseConfig = {
    apiKey: "AIzaSyCfbDEvntAjCft006d_t9fQuNwuVHmBl3s",
    authDomain: "masdemo-146c2.firebaseapp.com",
    databaseURL: "https://masdemo-146c2.firebaseio.com",
    projectId: "masdemo-146c2",
    storageBucket: "masdemo-146c2.appspot.com",
    messagingSenderId: "253329309704",
    appId: "1:253329309704:web:376b0267bee7a9dad411bd",
    measurementId: "G-XKDMFRXJBF"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  // firebase.analytics();
  
  var messagesRef = firebase.database().ref('messages');
  
  // Listen for form submit
  document.getElementById('contactForm').addEventListener('submit', submitForm);
  
  // Submit form
  function submitForm(e){
    e.preventDefault();
  
    // Get values
    var batch = getInputVal('batch');
    var layerLen = getInputVal('layerLen');
    var email = getInputVal('data1');
    var phone = getInputVal('data2');
    // var message = getInputVal('message');
  
    // Save message
    saveMessage(batch, layerLen, email, phone);
  
    // Show alert
    document.querySelector('.alert').style.display = 'block';
  
    // Hide alert after 3 seconds
    setTimeout(function(){
      document.querySelector('.alert').style.display = 'none';
    },3000);
  
    // Clear form
    document.getElementById('contactForm').reset();
  }
  
  // Submit form
  
  // Function to get get form values
  function getInputVal(id){
    return document.getElementById(id).value;
  }
  
  // Save message to firebase
  function saveMessage(batch, layerLen, email, phone){
    var newMessageRef = messagesRef.push();
    newMessageRef.set({
      batch: batch,
      layerLen:layerLen,
      email:email,
      phone:phone,
      message:message
    });
  }
  
  // Retreaving data from firebase
  /////////////////////////////////////////////////
  
  
  // database = firebase.database();
  // var ref = database.ref('batches');
  // ref.on('value', gotData, errData);
  
  // function gotData(data) {
  //   // console.log(data.val());
  //   var scores = data.val();
  //   var keys = Object.keys(scores);
  //   console.log(keys);
  // }
  
  // function errData(err){
  //   console.log("Error happened !");
  //   console.log(err);
  // }
  
  
  // // 
  
  // var ref = firebase.database().ref();
  
  // ref.on("value", function(snapshot) {
  //    console.log(snapshot.val());
  // }, function (error) {
  //    console.log("Error: " + error.code);
  // });